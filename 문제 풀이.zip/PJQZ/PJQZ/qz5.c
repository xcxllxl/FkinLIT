#include<stdio.h> 
int main()
{
printf("5������\n");
	int a = 0;
	for (int i = 1; i <= 100; i++)
	{
		a = a + i;
		printf("%d", a);
		if (i != 100)
		{
			printf("+");
		}
		else if (i == 100)
		{
			printf("\n");
		}
	}
	printf("total = %d\n", a);

	return 0;
}