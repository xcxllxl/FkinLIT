#include<stdio.h>
int q10(int num)
{
	if (num == 0)
		return 0;
	else if (num == 1)
		return 1;
	else
	{
		return q10(num - 1) + q10(num - 2);
	}

}

int main()
{
	int num;
	printf("n���� �Է�\n");
	scanf_s("%d", &num);
	printf("%d", q10(num));
}