#include<stdio.h>

int main() //8������
{

	int a;
	scanf_s("%d", &a);
	int num = 1;
	for (int i = 1; i <= a; i++)
	{
		num *= i;
	}
	//printf("%d", num);
	return num;

}