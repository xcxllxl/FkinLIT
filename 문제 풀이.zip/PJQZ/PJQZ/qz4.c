#include<stdio.h> //4�� ����

void sol(char a, char b) {
	char str[10] = "color ";
	str[6] = a;
	str[7] = b;

	system(str);
}

int main()
{
	char a, b;
	a = getchar();
	rewind(stdin);
	b = getchar();

	sol(a, b);

	return 0;
}