#include<stdio.h> 
int q5(int a, int b)
{
	int sum = 0;

	for (int i = 1; i <= 100; i++)
	{
		sum = sum + i;
		printf("%d", a);
		if (i != 100)
		{
			printf("+");
		}
		else if (i == 100)
		{
			printf("\n");
		}
	}
	printf("total = %d\n", a);

	return sum;
}


int q6(int a, int b)
{	
	int	num = 1;
	for (int i = a; i <= b; i++)
	{
		num *= i;
		printf("%d", i);

		if (i != b)
		{
			printf("x");
		}
		else if (i == b)
		{
			printf("=");
		}
	}
	printf("%d", num);
	return num;
}

int q7(int a, int b, char c)
{
	int num = 0;
	int sum = 0;
	switch (c)
	{
	case'+' :
		sum = q5(a, b);
		printf("%d\n", sum);
		break;

	case '*' :
	case 'x' :
		num = q6(a, b);
		printf("%d\n", num);
		break;

	default:
		printf(":+:error:+:\n");
		break;
	}
}

int main()
{
	int a, b;
	printf("a, b : ");
	scanf_s("%d %d", &a, &b);
	int result = q6(a, b);
	printf("%d\n", result);

	char c;
	printf("7�� ���� : a, b, c : ");
	rewind(stdin);
	scanf_s("%d %d %c", &a, &b, &c, sizeof(c));
	q7(a, b, c);

	
}