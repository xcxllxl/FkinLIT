#include<stdio.h> //6�� 
int main()
{
	printf("6������\n");
	int a,b;
	printf("a,b�� �Է�.\n");
	scanf_s("%d %d", &a, &b);
	int	num = 1;
	for (int i = a; i <= b; i++)
	{
		num *= i;
		printf("%d", i);

		if (i != b)
		{
			printf("x");
		}
		else if (i == b)
		{
			printf("=");
		}
	}
	printf("%d", num);
	return num;
		
}