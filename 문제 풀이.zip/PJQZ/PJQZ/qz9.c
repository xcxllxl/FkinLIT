#include<stdio.h>
int q9(int num)
{
	if (num <= 1)
	{
		return 1;
	}
	return num * q9(num - 1);
}

int main()
{
	printf("n���� �Է�\n");
	int n;
	scanf_s("%d", &n);
	
	int result = q9(n);
	printf("����� : %d\n", result);

	return 0;
}