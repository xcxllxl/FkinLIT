#include<stdio.h>
//1�� �Դϱ�
void upNum(int a, int b)
{
	if (a >= b) {
        printf("%d", a);
	}
	else {
		printf("%d", b);
	}
} //���׿�����  a >= b ? printf("%d\n", a) : printf("%d\n , b);
 //
//2�� �̳׿�
int rem(int a, int b)
{
	if (a >= b) {
		return a;
	}
	else {
		return b;
	}
}
//3�� �Դϴ�.
void swap(int a, int b)
{
	int ram = a;
	a = b;
	b = ram;
	printf("%d %d", a, b);
}


int main()
{
	int a, b;
	scanf_s("%d %d", &a, &b);
	upNum(a, b);
	printf("\n");
	swap(a, b);

	return 0;
}