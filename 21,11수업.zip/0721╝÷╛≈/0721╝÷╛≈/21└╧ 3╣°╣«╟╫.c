#include<stdio.h>
int a;
int b;

void swap(int* a, int* b)
{
	int temp = a;
	*a = *b;
	*b = temp;
}

int main()
{
	printf("���� 2�� �Է�");
    scanf_s("%d %d", &a, &b);
	printf("%d %d\n", a, b);
	int temp = a;
	a = b;
	b = temp;
	printf("%d %d\n", a, b);
	g_swap();
	printf(" %d %d\n", a, b);
	return 0;
}