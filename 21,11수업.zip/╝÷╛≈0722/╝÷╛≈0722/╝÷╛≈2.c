#include<stdio.h>
int main()
{
	int number[5];
	
	int size = sizeof(number) / sizeof(int);

	for (int i = 0; i < size; i++)
	{
		printf("%dù��° ���� �Է�", i);
		scanf_s("%d", &number[i]);
	}
	int max = number[0];
	int max_index = 0;
	for (int i = 1; i < size; i++)
	{
		if (max < number[i])
		{
			max = number[i];
			max_index = i;
		}
	}
	printf("�ִ밪��[%d]�� �����ϴ�.\n", max_index);

	return 0;
}