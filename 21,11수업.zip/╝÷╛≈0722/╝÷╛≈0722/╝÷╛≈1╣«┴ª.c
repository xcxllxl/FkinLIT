#include<stdio.h>
#include<stdlib.h>
int main()
{
	int size;
	scanf_s("%d", &size);
	int* dynamic_arr = (int*)calloc(size , sizeof(int));

	for (int i = 0; i < size; i++)
	{
		int n;
		printf("%dù��° ���� �Է�", i);
		scanf_s("%d", &n);
		dynamic_arr[i] = n;
	}
	int max = dynamic_arr[0];
	int idx = 0;
	for (int i = 0; i < size; i++)
	{
		if (max < dynamic_arr[i])
		{
			max = dynamic_arr[i];
			idx = i;
		}

	}
	printf("�ִ���[%d]�� �����ϴ�.\n", idx);
}