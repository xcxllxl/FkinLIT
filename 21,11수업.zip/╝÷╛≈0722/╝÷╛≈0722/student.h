#pragma once
struct Student
{
	int math;
	int eng;
	int kor;
}typedef Stu;