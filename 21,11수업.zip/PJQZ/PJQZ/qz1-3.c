#include<stdio.h>
//3�� ����
void sol() {
	system("color a0");

}


int main()
{
	sol();

	/*q1
	printf("1������\n");
	int a, b, c;
	scanf_s("%d %d %d", &a, &b, &c);
	int sum = 0;
		for (int i = a; i <= b; i++)
	{
			if (i % c == 0) {
			continue;
			}
			sum += i;
	}
		
			printf("%d",sum);
     */ 

	/*q2
	printf("2������\n")
	int sec;
	scanf_s("%d", &sec); 
	if (sec >= 3600) {
		printf("error\n");
	}
	else {
	int m = sec / 60;
	int s = sec % 60;
	printf("%d�� %d��", m, s);
	}
	*/

	
	return 0;
}

