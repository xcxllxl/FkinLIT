#include<stdio.h>
int main()
{
	int a = 0;
	for (int i = 1; i <= 100; i++) 
	{
		a = a + i;
		printf
	}
		printf("total = %d", a);
	

	return 0;
}